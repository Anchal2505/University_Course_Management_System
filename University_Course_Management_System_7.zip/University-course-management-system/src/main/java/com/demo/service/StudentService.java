package com.demo.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Assignment;
import com.demo.entity.Course;
import com.demo.entity.Student;
import com.demo.repository.CourseRepository;
import com.demo.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
    private StudentRepository studentRepository;
	
	 @Autowired
	    private CourseRepository courseRepository;

	 
	    // Get student by ID
	    public Student getStudentById(Long studentId) {
	        return studentRepository.findById(studentId)
	                .orElseThrow(() -> new RuntimeException("Student not found"));
	    }

	    // Update student details
	    public Student updateStudent(Long id, Student studentDetails) {
	        return studentRepository.findById(id).map(student -> {
	            student.setName(studentDetails.getName());
	            student.setEmail(studentDetails.getEmail());
	            student.setStudentProfile(studentDetails.getStudentProfile());
	            return studentRepository.save(student);
	        }).orElseThrow(() -> new RuntimeException("Student not found with id " + id));
	    }

	    // Delete student by ID
	    public void deleteStudent(Long id) {
	        studentRepository.deleteById(id);
	    }
	    
	    public Set<Course> getEnrolledCourses(Long studentId) {
	        Student student = getStudentById(studentId);
	        return student.getCourses();
	    }

	    public Student enrollStudentInCourse(Long studentId, Long courseId) {
	        Student student = getStudentById(studentId);
	        Course course = courseRepository.findById(courseId)
	                .orElseThrow(() -> new RuntimeException("Course not found"));

	        student.addCourse(course);
	        return studentRepository.save(student);
	    }

	    public Student withdrawStudentFromCourse(Long studentId, Long courseId) {
	        Student student = getStudentById(studentId);
	        Course course = courseRepository.findById(courseId)
	                .orElseThrow(() -> new RuntimeException("Course not found"));

	        student.removeCourse(course);
	        return studentRepository.save(student);
	    }
	    
	    
	    public Set<Assignment> getStudentAssignments(Long studentId) {
	        Student student = studentRepository.findById(studentId)
	                .orElseThrow(() -> new RuntimeException("Student not found"));

	        Set<Assignment> assignments = new HashSet<>();
	        for (Course course : student.getCourses()) {
	            assignments.addAll(course.getAssignments());
	        }

	        return assignments;
	    }
	    
	    
}
