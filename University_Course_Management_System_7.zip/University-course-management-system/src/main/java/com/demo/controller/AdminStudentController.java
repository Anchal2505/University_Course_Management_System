package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Student;
import com.demo.service.AdminStudentService;


@RestController
@RequestMapping("/api/admin/students")
public class AdminStudentController {
	
	 @Autowired
	    private AdminStudentService adminStudentService;
	 
	    // Create a new student
	    @PostMapping
	    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
	        Student savedStudent = adminStudentService.saveStudent(student);
	        return ResponseEntity.ok(savedStudent);
	    }

	    @GetMapping
	    public ResponseEntity<List<Student>> getAllStudents() {
	        return ResponseEntity.ok(adminStudentService.getAllStudents());
	    }
	    
	    @GetMapping("/{studentId}")
	    public ResponseEntity<Student> getStudentById(@PathVariable Long studentId) {
	        return ResponseEntity.ok(adminStudentService.getStudentById(studentId));
	    }
	    
	    public ResponseEntity<Student> updateStudent(@PathVariable Long studentId, @RequestBody Student student) {
	        return ResponseEntity.ok(adminStudentService.updateStudent(studentId, student));
	    }

	    @DeleteMapping("/{studentId}")
	    public ResponseEntity<Void> deleteStudent(@PathVariable Long studentId) {
	        adminStudentService.deleteStudent(studentId);
	        return ResponseEntity.noContent().build();
	    }
	    
	    @GetMapping("/count-by-course")
	    public ResponseEntity<Long> getStudentCountByCourse(@RequestParam String courseCode) {
	        return ResponseEntity.ok(adminStudentService.getStudentCountByCourseCode(courseCode));
	    }

}
