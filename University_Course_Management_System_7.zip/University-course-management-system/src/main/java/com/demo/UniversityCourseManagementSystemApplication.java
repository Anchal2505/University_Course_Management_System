package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EntityScan(basePackages = "com.demo.entity")
public class UniversityCourseManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityCourseManagementSystemApplication.class, args);
	}

}
